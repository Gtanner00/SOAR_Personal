Dowload and install Kicad.
Open STM32_SOAR_Reference_Board1.pro with Kicad

Open STM32_SOAR_Reference_Board1.sch to view the hierarchical schematic. Required libraries should be stored in the included cache file. 
